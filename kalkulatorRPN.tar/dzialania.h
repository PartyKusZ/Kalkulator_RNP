#include<stdio.h>
#include<stdlib.h>
#include"stos.h"
#include<ctype.h>
void dodawanie(t_stos **stos);
void odejmowanie(t_stos **stos);
void mnozenie(t_stos **stos);
void dzielenie(t_stos **stos);
void usun_szczyt(t_stos **stos);
void wyczysc_stos(t_stos **stos);
void zamien(t_stos **stos);
void podwoj(t_stos **stos);
void drukuj_szczyt(t_stos **stos);
void drukuj(t_stos **stos);

