#include<stdio.h>
#include<stdlib.h>
#include"stos.h"
#include<ctype.h>
void dodawanie(t_stos **stos);
void odejmowanie(t_stos **stos);
void mnozenie(t_stos **stos);
void dzielenie(t_stos **stos);
void usun_szczyt(t_stos **stos);
